--------------------------------------------------------------------------------------
Activation Type        Supported Product        Activation Period
--------------------------------------------------------------------------------------

HWID                -  Windows 10-11         -  Permanent                           
Ohook               -  Office                -  Permanent                           
KMS38               -  Windows 10-11-Server  -  Till the Year 2038                  
Online KMS          -  Windows / Office      -  180 Days. Lifetime With Renewal Task

--------------------------------------------------------------------------------------

For more details, use the respective docs section here https://massgrave.dev/